<?php

include_once BRIDGE_CORE_SHORTCODES_PATH.'/product-list/functions.php';
include_once BRIDGE_CORE_SHORTCODES_PATH.'/product-list/product-list.php';