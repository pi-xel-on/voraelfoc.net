<?php
require_once BRIDGE_CORE_SHORTCODES_PATH.'/_expanding-images/expanding-images.php';
