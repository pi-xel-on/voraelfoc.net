<?php

include_once BRIDGE_CORE_SHORTCODES_PATH.'/portfolio-project-slider/portfolio-project-slider.php';
include_once BRIDGE_CORE_SHORTCODES_PATH.'/portfolio-project-slider/helper-functions.php';