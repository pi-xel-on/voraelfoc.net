<div class="qode-hm-item" data-width="<?php echo esc_attr($width); ?>" style="width: <?php echo esc_attr($width); ?>px">
    <div class="qode-hm-item-inner qode-<?php echo esc_attr($align); ?>-aligned">
        <?php echo do_shortcode($content); ?>
    </div>
</div>