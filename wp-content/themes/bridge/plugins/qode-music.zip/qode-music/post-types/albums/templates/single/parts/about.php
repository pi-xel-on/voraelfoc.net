<h2 class="qode-about-album-holder-title"><?php esc_html_e('About Album', 'qode-music'); ?></h2>
<div class="qode-about-album-content">
	<?php the_content(); ?>
</div>